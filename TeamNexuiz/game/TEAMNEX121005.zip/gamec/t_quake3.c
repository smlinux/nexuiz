//***********************
//QUAKE 3 ENTITIES - So people can play quake3 maps with the nexuiz weapons
//***********************
void weapon_machinegun (void) {weapon_uzi();}
void weapon_plasmagun (void) {weapon_electro();}
void weapon_lightning (void) {weapon_crylink();}
void weapon_railgun (void) {weapon_nex();}
void weapon_bfg (void) {weapon_hagar();}
void item_slugs (void) {item_cells();}
void item_lightning (void) {item_cells();}
void item_armorshard (void) {item_armor1();}
void item_armorbody (void) {item_armor25();}
void item_armor_shard (void) {item_armor1();}
void item_armor_body (void) {item_armor25();}
void item_armor_combat (void) {item_armor25();}
void item_health_small (void) {item_health1();}
void item_health_large (void) {item_health25();}
void item_health_mega (void) {item_health100();}
