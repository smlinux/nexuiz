
// Accuracy
//.float shots;
//.float hits;

