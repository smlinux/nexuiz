void CopyBody(float keepvelocity);

// changes by LordHavoc on 03/30/04
// cleaned up dummy code
// dummies are now removed eventually after being gibbed (norespawn = TRUE)
// dummy impulse now checks sv_cheats to prevent players from overwhelming server with dummies
// dummies now use player code where possible

void player_anim (void);
void DummyThink(void)
{
	self.think = DummyThink;
	self.nextthink = time;
	SV_PlayerPhysics();
	PlayerPreThink();
	//player_anim();
	PlayerPostThink();
}

void CopyBody2(float keepvelocity, float testbody);
void ImpulseCommands (void)
{
	if (self.impulse == 8) {
	TeamFortress_ThrowGrenade(); }
	if ((self.impulse == 150))		// GREN TYPE 1
	{
		TeamFortress_PrimeGrenade();
	}
/*	if ((self.impulse == 151))		// GREN TYPE 2
	{
		TeamFortress_PrimeGrenade();
	}*/
	if ((self.impulse == 152))
	{
		TeamFortress_ThrowGrenade();
	}

	if (self.impulse >= 1 && self.impulse <= 5)
	{
		if(self.buttonuse)
		{
			if(self.impulse == 5 && self.wpn5.weapon)
			{
				weapon_action(self.weapon, WR_DROP);
				SpawnThrownWeapon (self.origin + (self.mins + self.maxs) * 0.5, self.wpn5.weapon);
				self.weapon = 0;
				ResetExtraWeapon();
				self.switchweapon = w_getbestweapon(self);
				if(self.switchweapon == WEP5)
					self.switchweapon = WEP1;
			}
		}
		else
			W_SwitchWeapon (self.impulse);
	}
	else if (self.impulse == 10)
		W_NextWeapon ();
	else if (self.impulse == 12)
		W_PreviousWeapon ();
	else if (self.impulse == 13 && cvar("sv_cheats"))
	{
		makevectors (self.v_angle);
		self.velocity = self.velocity + v_forward * 300;
		CopyBody2(1, TRUE);
		self.velocity = self.velocity - v_forward * 300;
	}
	else if (self.impulse == 14 && cvar("sv_cheats"))
		CopyBody2(0, TRUE);
	else if (self.impulse == 99 && cvar("sv_cheats"))
	{
		self.items = IT_WEP1 | IT_WEP2 | IT_WEP3 | IT_WEP4 | IT_WEP5;
		self.ammo_shells = 999;
		self.ammo_nails = 999;
		self.ammo_rockets = 999;
		self.ammo_cells = 999;
	}

	if(self.impulse == 20)
	{
		ClassSpecial();
	}

	if(self.impulse == 30)
	{
		ClassGrenade(WR_GRENADE1);
	}
	if(self.impulse == 31)
	{
		ClassGrenade(WR_GRENADE2);
	}

	// model/class test
	if(self.impulse == 57)
	{
		//self.class = GetPlayerClass();
		sprint(self, "Current class: ");
		sprint(self, NameOfClass(self.class));
		sprint(self, ", model: ");
		sprint(self, self.playermodel);
		sprint(self, "\n");
	}
	if(self.impulse == 211)		// XavioR test impulse
	{
		local string woottest;
		woottest = ftos(self.team_no);
		sprint (self, woottest);
		sprint (self, "\n");
	}
	//TetrisImpulses();
	self.impulse = 0;
}